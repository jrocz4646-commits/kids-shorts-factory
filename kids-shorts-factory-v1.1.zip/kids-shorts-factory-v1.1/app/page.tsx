 "use client";
import { useState } from "react";
import Link from "next/link";

export default function Home(){
  return <div className="shell">
    <nav className="nav"><div className="brand"><span className="brandmark">🦈</span> Kids Shorts Factory</div><div className="navlinks"><a href="#features">Features</a><a href="#pricing">Pricing</a><Link href="/app">Open App →</Link></div></nav>
    <main>
      <section className="hero">
        <div><span className="eyebrow">AI content studio for kids creators</span><h1>One idea.<br/>One complete Short.</h1><p>Turn a simple kids-video idea into a ready-to-produce YouTube Short with a script, lyrics, characters, scenes, captions and publishing copy.</p><Link href="/app"><button className="cta">✨ Create a Short</button></Link></div>
        <div className="demo"><div className="demo-top"><strong>🦈 Baby Shark Dinosaur Day</strong><span className="pill">60 sec</span></div><div className="scene"><strong>HOOK</strong><small>“Baby Shark found something BIG behind the jungle tree!”</small></div><div className="scene"><strong>SCENE 1 • 0:00–0:06</strong><small>Baby Shark swims into a colorful prehistoric jungle.</small></div><div className="scene"><strong>CAPTION</strong><small>WHAT'S THAT?! 🦖</small></div><div className="scene"><strong>🎵 LYRICS</strong><small>Baby Shark swims along, Dino friends are singing songs...</small></div></div>
      </section>
      <section className="section" id="features"><h2>Everything creators need.</h2><p className="muted">Start with the production blueprint. Add automated visuals and video later.</p><div className="features"><div className="card"><h3>🎬 Complete scripts</h3><p className="muted">Hooks, narration, lyrics and a satisfying ending designed for preschool attention spans.</p></div><div className="card"><h3>🧸 Consistent characters</h3><p className="muted">Save recurring characters and reuse their descriptions across future episodes.</p></div><div className="card"><h3>📤 YouTube-ready</h3><p className="muted">Titles, descriptions, hashtags, captions and thumbnail prompts in one place.</p></div></div></section>
      <section className="section" id="pricing"><h2>Simple pricing.</h2><div className="pricing"><div className="card"><h3>Free</h3><div className="price">$0</div><p>3 projects / month</p><button className="pricebtn">Start Free</button></div><div className="card"><h3>Creator</h3><div className="price">$9.99</div><p>50 projects / month</p><button className="pricebtn">Choose Creator</button></div><div className="card"><h3>Pro</h3><div className="price">$19.99</div><p>200 projects / month</p><button className="pricebtn">Choose Pro</button></div></div></section>
    </main><footer className="footer">© 2026 Kids Shorts Factory • Built for kids-content creators</footer>
  </div>
}