import { NextResponse } from "next/server";

const fallback = {
  title:"Your Kids Adventure",
  hook:"Look! Something amazing is hiding just around the corner!",
  lyrics:"Come along and sing today, clap your hands and shout hooray! Friends together, hip hip hooray—let's have fun and play!",
  characters:["Main character — cute, friendly preschool cartoon character with large expressive eyes and bright simple colors.","Friend — cheerful, gentle preschool character with rounded features and a playful smile."],
  scenes:Array.from({length:7},(_,i)=>({number:i+1,time:`Scene ${i+1}`,narration:"A cheerful moment in the adventure.",visual:"Bright colorful preschool cartoon scene, friendly characters, simple shapes, joyful expression, consistent character design.",caption:"LET'S GO! 🎉"})),
  youtube_title:"Fun Kids Adventure! | Sing Along Short for Kids",
  youtube_description:"A cheerful, colorful kids adventure made for preschool viewers.",
  hashtags:["#KidsShorts","#KidsSongs","#NurseryRhymes","#Preschool"],
  thumbnail_prompt:"Bright colorful preschool cartoon characters having a joyful adventure, large expressive eyes, clean composition, high contrast, no text."
};

export async function POST(req:Request){
  try{
    const {idea,age="4–6",format="Nursery rhyme",duration="60 seconds"}=await req.json();
    if(!idea) return NextResponse.json({error:"Idea is required."},{status:400});
    const key=process.env.OPENAI_API_KEY;
    if(!key) return NextResponse.json({...fallback,title:idea.length>50?idea.slice(0,50)+"…":idea,hook:`${idea} — let’s see what happens!`});
    const prompt=`You are an expert children's YouTube Shorts producer. Create a ${duration} kids Short for ages ${age}. Format: ${format}. Idea: ${idea}. Keep it joyful, simple, non-scary, preschool-safe, highly visual, and original. Return ONLY valid JSON with exactly these keys: title, hook, lyrics, characters (array of strings), scenes (array of objects with number,time,narration,visual,caption), youtube_title, youtube_description, hashtags (array of strings), thumbnail_prompt. Make 7 scenes for 60 seconds, 4 scenes for 30 seconds, 10 scenes for 90 seconds. Keep recurring character descriptions consistent. Do not imitate copyrighted characters or lyrics.`;
    const response=await fetch("https://api.openai.com/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`},body:JSON.stringify({model:process.env.OPENAI_MODEL||"gpt-4o-mini",temperature:.8,response_format:{type:"json_object"},messages:[{role:"system",content:"You create safe, original children's content."},{role:"user",content:prompt}]})});
    if(!response.ok) throw new Error("AI provider request failed");
    const data=await response.json();
    return NextResponse.json(JSON.parse(data.choices[0].message.content));
  }catch(e){return NextResponse.json({error:"Generation failed. Check your API key and try again."},{status:500})}
}