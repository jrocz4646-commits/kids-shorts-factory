import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Kids Shorts Factory",
  description: "Turn one idea into a complete kids YouTube Short.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}