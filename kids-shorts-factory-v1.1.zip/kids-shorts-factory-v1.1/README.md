# Kids Shorts Factory

A mobile-friendly MVP that turns a kids-video idea into a production-ready YouTube Short blueprint.

## Included
- Landing page
- Create Short flow
- AI generation endpoint
- Story, scenes, characters and publishing tabs
- Free/Creator/Pro pricing UI
- Responsive design
- Demo fallback when no API key is configured

## Run locally

1. Install Node.js 18+.
2. Copy `.env.example` to `.env.local`.
3. Add your OpenAI API key.
4. Run:

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Deploy

The easiest path is Vercel:
1. Put this project in a GitHub repository.
2. Import the repository into Vercel.
3. Add `OPENAI_API_KEY` and optionally `OPENAI_MODEL` as environment variables.
4. Deploy.

## Important before charging customers
This MVP intentionally leaves authentication, persistent database storage, Stripe checkout, and automated video generation as the next production steps. Do not treat the pricing buttons as live payments until Stripe and user accounts are connected.

## Product roadmap
1. Auth + Supabase projects
2. Stripe subscriptions and usage limits
3. Character library
4. Batch "Create 30 Shorts"
5. Image generation
6. Voiceover/music
7. Video assembly/export
8. YouTube publishing integration


## V1.1 launch files
- `.env.local.example` lists all required production environment variables.
- `LAUNCH_CHECKLIST.md` gives the account/deployment setup.
- `/api/health` provides a simple deployment health check.
- `/privacy` and `/terms` are placeholders that must be reviewed/replaced before launch.
