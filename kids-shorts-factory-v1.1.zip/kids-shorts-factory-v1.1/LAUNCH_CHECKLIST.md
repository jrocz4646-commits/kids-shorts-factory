# Kids Shorts Factory — Launch Checklist

## 1. OpenAI
- Create an API key in your OpenAI account.
- Add it as `OPENAI_API_KEY` in your hosting provider.
- Never expose this key in browser/client code.

## 2. Supabase
Create a Supabase project and add these environment variables:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

Recommended production tables:
- profiles: id, email, plan, monthly_project_count, created_at
- projects: id, user_id, title, idea, age_group, format, duration, content_json, created_at, updated_at
- characters: id, user_id, name, description, visual_prompt, created_at

Enable Row Level Security so users can only read/write their own records.

## 3. Stripe
Create two recurring prices:
- Creator — $9.99/month
- Pro — $19.99/month

Add their Price IDs as:
- `STRIPE_CREATOR_PRICE_ID`
- `STRIPE_PRO_PRICE_ID`

Configure a Stripe webhook pointing to your deployed `/api/stripe/webhook` endpoint and set:
- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`

Use Stripe Checkout for subscriptions and customer portal for billing management.

## 4. Deploy
Recommended:
1. Push project to GitHub.
2. Import into Vercel.
3. Add environment variables.
4. Deploy.
5. Add your custom domain.
6. Test signup, generation, saving, subscription, cancellation and usage limits before public launch.

## 5. Before accepting real customers
- Replace demo pricing buttons with real Stripe Checkout.
- Add authentication and database persistence.
- Add rate limiting.
- Add server-side authorization.
- Add a production privacy policy and terms reviewed for your jurisdiction.
- Set a monthly AI budget/usage alert.
- Test child-safety/content moderation and avoid collecting unnecessary information from children.
